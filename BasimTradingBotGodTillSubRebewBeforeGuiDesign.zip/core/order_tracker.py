def track_order_execution(order):
    # يمكنك تحسين الدالة لاحقًا أو وضع منطقك هنا
    return True