import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
)
from core.auth import login
from database.db_manager import get_device_id, set_device_id, check_user_status
import platform
from tg_bot.bot import send_activation_request
from core.translation_utils import load_translation
from gui.main_window import MainWindow  # سننشئه في الخطوة التالية

def get_device_fingerprint():
    return platform.node() + "_" + platform.system()

class LoginWindow(QWidget):
    def __init__(self, lang="en"):
        super().__init__()
        self.lang = lang
        self.trans = load_translation(self.lang)
        self.setWindowTitle(self.trans["login_title"])
        self.setGeometry(400, 200, 350, 200)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.label_user = QLabel(self.trans["username"])
        self.input_user = QLineEdit()
        self.label_pass = QLabel(self.trans["password"])
        self.input_pass = QLineEdit()
        self.input_pass.setEchoMode(QLineEdit.Password)
        self.btn_login = QPushButton(self.trans["login"])
        self.btn_login.clicked.connect(self.handle_login)
        layout.addWidget(self.label_user)
        layout.addWidget(self.input_user)
        layout.addWidget(self.label_pass)
        layout.addWidget(self.input_pass)
        layout.addWidget(self.btn_login)
        self.setLayout(layout)

    def handle_login(self):
        username = self.input_user.text().strip()
        password = self.input_pass.text().strip()
        device_id = get_device_fingerprint()
        result = login(username, password)
        if result["status"] == "success":
            if result["role"] == "superuser":
                QMessageBox.information(self, "Success", self.trans["success_superuser"])
                self.open_main_window()
            else:
                saved_device = get_device_id(username)
                if not saved_device:
                    set_device_id(username, device_id)
                    QMessageBox.information(self, "Info", self.trans["first_device"])
                    self.open_main_window()
                elif saved_device != device_id:
                    QMessageBox.critical(self, "Error", self.trans["device_error"])
                else:
                    QMessageBox.information(self, "Success", self.trans["success_user"])
                    self.open_main_window()
        else:
            status = check_user_status(username)
            if status == "pending":
                send_activation_request(username, device_id)
                QMessageBox.warning(self, "Pending", self.trans["pending"])
            elif status == "rejected":
                QMessageBox.critical(self, "Rejected", self.trans["rejected"])
            else:
                QMessageBox.critical(self, "Error", self.trans["invalid"])

    def open_main_window(self):
        self.main_window = MainWindow(lang=self.lang)
        self.main_window.show()
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginWindow(lang="en")  # أو "ar" كبداية
    window.show()
    sys.exit(app.exec_())