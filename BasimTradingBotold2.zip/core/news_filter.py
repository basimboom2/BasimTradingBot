
# مؤقتًا: إرجاع True دائمًا لأن مراقبة الأخبار لم تُنفذ بعد

def is_safe_to_trade():
    return True
