import nest_asyncio
nest_asyncio.apply()

from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CallbackQueryHandler, MessageHandler, filters
import logging
import asyncio

logging.basicConfig(level=logging.DEBUG)

BOT_TOKEN = "7963470425:AAGTxK3QAiK-qvSpYoe0suh1Q4ivWoi3rfs"
GROUP_CHAT_ID = -1002874958202  # ضع هنا chat_id الجروب بالسالب

async def button(update: Update, context):
    query = update.callback_query
    await query.answer()
    if query.data == "approve_test":
        await query.edit_message_text("تمت الموافقة!")
    elif query.data == "reject_test":
        await query.edit_message_text("تم الرفض!")

async def send_test_message():
    bot = Bot(token=BOT_TOKEN)
    keyboard = [
        [
            InlineKeyboardButton("✅ موافقة", callback_data="approve_test"),
            InlineKeyboardButton("❌ رفض", callback_data="reject_test")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await bot.send_message(chat_id=GROUP_CHAT_ID, text="اختبار الأزرار في الجروب", reply_markup=reply_markup)

async def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: None))
    print("بوت الاختبار يعمل...")
    await send_test_message()
    await app.run_polling()

if __name__ == "__main__":
    asyncio.run(main())